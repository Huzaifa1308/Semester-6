attempts = 0
dead_ends = 0

def read_puzzle(path):
    grid = []
    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if len(line) != 9:
                print("Bad row:", line)
                exit()
            grid.append([int(x) for x in line])

    if len(grid) != 9:
        print("Need 9 rows, got:", len(grid))
        exit()

    return grid


def display(grid):
    for row in grid:
        print(" ".join(map(str, row)))


def next_blank(grid):
    for i in range(9):
        for j in range(9):
            if grid[i][j] == 0:
                return i, j
    return None


def can_place(grid, row, col, num):
    if num in grid[row]:
        return False

    for i in range(9):
        if grid[i][col] == num:
            return False

    sr = row - row % 3
    sc = col - col % 3
    for i in range(3):
        for j in range(3):
            if grid[sr + i][sc + j] == num:
                return False

    return True


def still_solvable(grid):
    for i in range(9):
        for j in range(9):
            if grid[i][j] == 0:
                options = 0
                for n in range(1, 10):
                    if can_place(grid, i, j, n):
                        options += 1
                if options == 0:
                    return False
    return True


def solve(grid):
    global attempts, dead_ends
    attempts += 1

    blank = next_blank(grid)
    if not blank:
        return True

    row, col = blank

    for num in range(1, 10):
        if can_place(grid, row, col, num):
            grid[row][col] = num

            if still_solvable(grid):
                if solve(grid):
                    return True

            grid[row][col] = 0

    dead_ends += 1
    return False


if __name__ == "__main__":
    print("Pick a difficulty:")
    print("1. Easy")
    print("2. Medium")
    print("3. Hard")
    print("4. Very Hard")

    pick = input("Choice (1-4): ")

    if pick == "1":
        path = "D:/SEMESTER 6/AI/easy.txt"
    elif pick == "2":
        path = "D:/SEMESTER 6/AI/medium.txt"
    elif pick == "3":
        path = "D:/SEMESTER 6/AI/hard.txt"
    elif pick == "4":
        path = "D:/SEMESTER 6/AI/veryhard.txt"
    else:
        print("Invalid choice")
        exit()

    attempts = 0
    dead_ends = 0

    grid = read_puzzle(path)

    print("\nPuzzle:")
    display(grid)

    if solve(grid):
        print("\nSolution:")
        display(grid)
    else:
        print("Couldn't solve it")

    print("\nRecursive calls:", attempts)
    print("Backtracks:", dead_ends)